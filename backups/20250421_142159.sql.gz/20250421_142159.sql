--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

-- Started on 2025-04-21 09:22:00 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 34707)
-- Name: AuthCodes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."AuthCodes" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    link character varying(255),
    valid_till timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."AuthCodes" OWNER TO admin;

--
-- TOC entry 215 (class 1259 OID 34712)
-- Name: AuthCodes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."AuthCodes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AuthCodes_id_seq" OWNER TO admin;

--
-- TOC entry 3498 (class 0 OID 0)
-- Dependencies: 215
-- Name: AuthCodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."AuthCodes_id_seq" OWNED BY public."AuthCodes".id;


--
-- TOC entry 216 (class 1259 OID 34713)
-- Name: Files; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Files" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    mimetype character varying(255) NOT NULL,
    material_id integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Files" OWNER TO admin;

--
-- TOC entry 217 (class 1259 OID 34718)
-- Name: PasswordResetTokens; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PasswordResetTokens" (
    id integer NOT NULL,
    token character varying(255) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."PasswordResetTokens" OWNER TO admin;

--
-- TOC entry 218 (class 1259 OID 34721)
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."PasswordResetTokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PasswordResetTokens_id_seq" OWNER TO admin;

--
-- TOC entry 3499 (class 0 OID 0)
-- Dependencies: 218
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."PasswordResetTokens_id_seq" OWNED BY public."PasswordResetTokens".id;


--
-- TOC entry 219 (class 1259 OID 34722)
-- Name: Roles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public."Roles" OWNER TO admin;

--
-- TOC entry 220 (class 1259 OID 34725)
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Roles_id_seq" OWNER TO admin;

--
-- TOC entry 3500 (class 0 OID 0)
-- Dependencies: 220
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- TOC entry 221 (class 1259 OID 34726)
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO admin;

--
-- TOC entry 222 (class 1259 OID 34729)
-- Name: Users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    phone character varying(255),
    name character varying(255),
    lastname character varying(255),
    areasofactivity character varying(255),
    review character varying(255),
    "googleId" character varying(255),
    "roleId" integer
);


ALTER TABLE public."Users" OWNER TO admin;

--
-- TOC entry 223 (class 1259 OID 34734)
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO admin;

--
-- TOC entry 3501 (class 0 OID 0)
-- Dependencies: 223
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- TOC entry 224 (class 1259 OID 34735)
-- Name: courses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.courses OWNER TO admin;

--
-- TOC entry 225 (class 1259 OID 34742)
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO admin;

--
-- TOC entry 3502 (class 0 OID 0)
-- Dependencies: 225
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- TOC entry 226 (class 1259 OID 34743)
-- Name: exercises; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.exercises (
    exercise_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    lesson_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.exercises OWNER TO admin;

--
-- TOC entry 227 (class 1259 OID 34750)
-- Name: exercises_exercise_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.exercises_exercise_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercises_exercise_id_seq OWNER TO admin;

--
-- TOC entry 3503 (class 0 OID 0)
-- Dependencies: 227
-- Name: exercises_exercise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.exercises_exercise_id_seq OWNED BY public.exercises.exercise_id;


--
-- TOC entry 228 (class 1259 OID 34751)
-- Name: lessons; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.lessons (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text,
    "isReviewLesson" boolean,
    priority_config jsonb DEFAULT '{"Video": 2, "EditorJS": 1, "AdditionalMaterials": 3}'::jsonb,
    course_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lessons OWNER TO admin;

--
-- TOC entry 229 (class 1259 OID 34759)
-- Name: lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lessons_id_seq OWNER TO admin;

--
-- TOC entry 3504 (class 0 OID 0)
-- Dependencies: 229
-- Name: lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.lessons_id_seq OWNED BY public.lessons.id;


--
-- TOC entry 230 (class 1259 OID 34760)
-- Name: materials; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.materials (
    material_id integer NOT NULL,
    title character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    file_path text NOT NULL,
    lesson_id integer
);


ALTER TABLE public.materials OWNER TO admin;

--
-- TOC entry 231 (class 1259 OID 34765)
-- Name: materials_material_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.materials_material_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.materials_material_id_seq OWNER TO admin;

--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 231
-- Name: materials_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.materials_material_id_seq OWNED BY public.materials.material_id;


--
-- TOC entry 232 (class 1259 OID 34766)
-- Name: progresses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.progresses (
    progress_id integer NOT NULL,
    user_id integer NOT NULL,
    lesson_id integer,
    status character varying(50) DEFAULT 'not_started'::character varying,
    isfinished character varying(50) DEFAULT 'no'::character varying,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.progresses OWNER TO admin;

--
-- TOC entry 233 (class 1259 OID 34773)
-- Name: progresses_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.progresses_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progresses_progress_id_seq OWNER TO admin;

--
-- TOC entry 3506 (class 0 OID 0)
-- Dependencies: 233
-- Name: progresses_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.progresses_progress_id_seq OWNED BY public.progresses.progress_id;


--
-- TOC entry 234 (class 1259 OID 34774)
-- Name: stream_students; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.stream_students (
    id integer NOT NULL,
    "streamId" integer NOT NULL,
    "userId" integer NOT NULL,
    "joinedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.stream_students OWNER TO admin;

--
-- TOC entry 235 (class 1259 OID 34778)
-- Name: stream_students_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.stream_students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stream_students_id_seq OWNER TO admin;

--
-- TOC entry 3507 (class 0 OID 0)
-- Dependencies: 235
-- Name: stream_students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.stream_students_id_seq OWNED BY public.stream_students.id;


--
-- TOC entry 236 (class 1259 OID 34779)
-- Name: streams; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.streams (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "startDate" timestamp with time zone NOT NULL,
    "endDate" timestamp with time zone NOT NULL,
    cost numeric(10,2) NOT NULL,
    "maxStudents" integer NOT NULL,
    "courseId" integer NOT NULL,
    "teacherId" integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.streams OWNER TO admin;

--
-- TOC entry 237 (class 1259 OID 34782)
-- Name: streams_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.streams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.streams_id_seq OWNER TO admin;

--
-- TOC entry 3508 (class 0 OID 0)
-- Dependencies: 237
-- Name: streams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.streams_id_seq OWNED BY public.streams.id;


--
-- TOC entry 3254 (class 2604 OID 34783)
-- Name: AuthCodes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AuthCodes" ALTER COLUMN id SET DEFAULT nextval('public."AuthCodes_id_seq"'::regclass);


--
-- TOC entry 3255 (class 2604 OID 34784)
-- Name: PasswordResetTokens id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens" ALTER COLUMN id SET DEFAULT nextval('public."PasswordResetTokens_id_seq"'::regclass);


--
-- TOC entry 3256 (class 2604 OID 34785)
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- TOC entry 3257 (class 2604 OID 34786)
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- TOC entry 3258 (class 2604 OID 34787)
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- TOC entry 3261 (class 2604 OID 34788)
-- Name: exercises exercise_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises ALTER COLUMN exercise_id SET DEFAULT nextval('public.exercises_exercise_id_seq'::regclass);


--
-- TOC entry 3264 (class 2604 OID 34789)
-- Name: lessons id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons ALTER COLUMN id SET DEFAULT nextval('public.lessons_id_seq'::regclass);


--
-- TOC entry 3268 (class 2604 OID 34790)
-- Name: materials material_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials ALTER COLUMN material_id SET DEFAULT nextval('public.materials_material_id_seq'::regclass);


--
-- TOC entry 3269 (class 2604 OID 34791)
-- Name: progresses progress_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses ALTER COLUMN progress_id SET DEFAULT nextval('public.progresses_progress_id_seq'::regclass);


--
-- TOC entry 3274 (class 2604 OID 34792)
-- Name: stream_students id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students ALTER COLUMN id SET DEFAULT nextval('public.stream_students_id_seq'::regclass);


--
-- TOC entry 3276 (class 2604 OID 34793)
-- Name: streams id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams ALTER COLUMN id SET DEFAULT nextval('public.streams_id_seq'::regclass);


--
-- TOC entry 3469 (class 0 OID 34707)
-- Dependencies: 214
-- Data for Name: AuthCodes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."AuthCodes" (id, email, link, valid_till, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3471 (class 0 OID 34713)
-- Dependencies: 216
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Files" (id, name, path, mimetype, material_id, "createdAt", "updatedAt") FROM stdin;
e4965860-8683-400c-b960-f0428097194e	фыфыа	uploads/фыфыа.MP4	video/mp4	\N	2025-04-21 07:30:34.272+00	2025-04-21 07:30:34.272+00
16c7bef3-7a47-47de-b02d-2fc586d1c8ad	ывмывм	uploads/ывмывм.MP4	video/mp4	\N	2025-04-21 07:30:47.563+00	2025-04-21 07:30:47.563+00
\.


--
-- TOC entry 3472 (class 0 OID 34718)
-- Dependencies: 217
-- Data for Name: PasswordResetTokens; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."PasswordResetTokens" (id, token, "expiresAt", "userId") FROM stdin;
\.


--
-- TOC entry 3474 (class 0 OID 34722)
-- Dependencies: 219
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Roles" (id, name) FROM stdin;
1	admin
2	teacher
3	student
\.


--
-- TOC entry 3476 (class 0 OID 34726)
-- Dependencies: 221
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250203054239-create-auth-code.js
20250203054925-role.js
20250203054926-user.js
20250203072631-create-courses.js
20250203072650-create-lessons.js
20250203072651-create-exercises.js
20250203072707-create-materials.js
20250203072714-create-progresses.js
20250219054000-create-streams.js
20250219111854-create-stream-students.js
20250221062332-create-file.js
20250221074440-add-material-id-to-files.js
20250306071613-create-password-reset-token.js
\.


--
-- TOC entry 3477 (class 0 OID 34729)
-- Dependencies: 222
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Users" (id, email, password, phone, name, lastname, areasofactivity, review, "googleId", "roleId") FROM stdin;
1	admin@example.com	$2a$10$2ynlBGQSmbxnlh3dg9sgp.w8lLcmhN5boyPuhmKZUujdghIgMDnB2	1234567890	Admin	User	\N	\N	\N	1
2	teacher@example.com	$2a$10$wsUN6lv4f2E9DKPidbCHaeGJ/ikLtmDdRAcK8CKAKVKl5Yo4WFKlm	0987654321	Teacher	User	\N	\N	\N	2
3	student@example.com	$2a$10$91pGDHHwgNmeHGIoGWrNZ.2Cl7gmibgGyVRepnPsembNwH1L0fnC2	5555555555	Student	User	\N	\N	\N	3
\.


--
-- TOC entry 3479 (class 0 OID 34735)
-- Dependencies: 224
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.courses (id, title, description, created_at, updated_at) FROM stdin;
1	buildingSmart	some descr	2025-04-21 05:18:29.275+00	2025-04-21 05:18:29.275+00
\.


--
-- TOC entry 3481 (class 0 OID 34743)
-- Dependencies: 226
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.exercises (exercise_id, title, description, lesson_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3483 (class 0 OID 34751)
-- Dependencies: 228
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lessons (id, title, content, "isReviewLesson", priority_config, course_id, created_at, updated_at) FROM stdin;
1	Занятие 1	{"time":1745220591250,"blocks":[{"id":"XjP6ZB2pBP","type":"paragraph","data":{"text":"Текст для урока 1"}}],"version":"2.31.0-rc.7"}	f	{"Video": 2, "EditorJS": 1, "AdditionalMaterials": 3}	1	2025-04-21 07:29:51.273+00	2025-04-21 07:29:51.273+00
2	Занятие 2	{"time":1745220610546,"blocks":[{"id":"DfAS0iob12","type":"paragraph","data":{"text":"Текст для урока 2"}}],"version":"2.31.0-rc.7"}	f	{"Video": 2, "EditorJS": 1, "AdditionalMaterials": 3}	1	2025-04-21 07:30:10.555+00	2025-04-21 07:30:10.555+00
\.


--
-- TOC entry 3485 (class 0 OID 34760)
-- Dependencies: 230
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.materials (material_id, title, type, file_path, lesson_id) FROM stdin;
1	фыфыа	video	http://localhost:4000/uploads/фыфыа.MP4	1
2	ывмывм	video	http://localhost:4000/uploads/ывмывм.MP4	2
\.


--
-- TOC entry 3487 (class 0 OID 34766)
-- Dependencies: 232
-- Data for Name: progresses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.progresses (progress_id, user_id, lesson_id, status, isfinished, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3489 (class 0 OID 34774)
-- Dependencies: 234
-- Data for Name: stream_students; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.stream_students (id, "streamId", "userId", "joinedAt") FROM stdin;
\.


--
-- TOC entry 3491 (class 0 OID 34779)
-- Dependencies: 236
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.streams (id, name, "startDate", "endDate", cost, "maxStudents", "courseId", "teacherId", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3509 (class 0 OID 0)
-- Dependencies: 215
-- Name: AuthCodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."AuthCodes_id_seq"', 1, false);


--
-- TOC entry 3510 (class 0 OID 0)
-- Dependencies: 218
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."PasswordResetTokens_id_seq"', 1, false);


--
-- TOC entry 3511 (class 0 OID 0)
-- Dependencies: 220
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 1, false);


--
-- TOC entry 3512 (class 0 OID 0)
-- Dependencies: 223
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Users_id_seq"', 1, false);


--
-- TOC entry 3513 (class 0 OID 0)
-- Dependencies: 225
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.courses_id_seq', 1, false);


--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 227
-- Name: exercises_exercise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.exercises_exercise_id_seq', 1, false);


--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 229
-- Name: lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lessons_id_seq', 1, false);


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 231
-- Name: materials_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.materials_material_id_seq', 1, false);


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 233
-- Name: progresses_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.progresses_progress_id_seq', 1, false);


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 235
-- Name: stream_students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.stream_students_id_seq', 1, false);


--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 237
-- Name: streams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.streams_id_seq', 1, false);


--
-- TOC entry 3278 (class 2606 OID 34795)
-- Name: AuthCodes AuthCodes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AuthCodes"
    ADD CONSTRAINT "AuthCodes_pkey" PRIMARY KEY (id);


--
-- TOC entry 3280 (class 2606 OID 34797)
-- Name: Files Files_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY (id);


--
-- TOC entry 3282 (class 2606 OID 34799)
-- Name: PasswordResetTokens PasswordResetTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_pkey" PRIMARY KEY (id);


--
-- TOC entry 3284 (class 2606 OID 34801)
-- Name: PasswordResetTokens PasswordResetTokens_token_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_token_key" UNIQUE (token);


--
-- TOC entry 3286 (class 2606 OID 34803)
-- Name: Roles Roles_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_name_key" UNIQUE (name);


--
-- TOC entry 3288 (class 2606 OID 34805)
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- TOC entry 3290 (class 2606 OID 34807)
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- TOC entry 3292 (class 2606 OID 34809)
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- TOC entry 3294 (class 2606 OID 34811)
-- Name: Users Users_googleId_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_googleId_key" UNIQUE ("googleId");


--
-- TOC entry 3296 (class 2606 OID 34813)
-- Name: Users Users_phone_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_phone_key" UNIQUE (phone);


--
-- TOC entry 3298 (class 2606 OID 34815)
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- TOC entry 3300 (class 2606 OID 34817)
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- TOC entry 3302 (class 2606 OID 34819)
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (exercise_id);


--
-- TOC entry 3304 (class 2606 OID 34821)
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- TOC entry 3306 (class 2606 OID 34823)
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (material_id);


--
-- TOC entry 3308 (class 2606 OID 34825)
-- Name: progresses progresses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_pkey PRIMARY KEY (progress_id);


--
-- TOC entry 3310 (class 2606 OID 34827)
-- Name: stream_students stream_students_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT stream_students_pkey PRIMARY KEY (id);


--
-- TOC entry 3312 (class 2606 OID 34829)
-- Name: streams streams_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_name_key UNIQUE (name);


--
-- TOC entry 3314 (class 2606 OID 34831)
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3315 (class 2606 OID 34832)
-- Name: Files Files_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_material_id_fkey" FOREIGN KEY (material_id) REFERENCES public.materials(material_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3316 (class 2606 OID 34837)
-- Name: PasswordResetTokens PasswordResetTokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3317 (class 2606 OID 34842)
-- Name: Users Users_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Roles"(id);


--
-- TOC entry 3318 (class 2606 OID 34847)
-- Name: exercises exercises_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- TOC entry 3319 (class 2606 OID 34852)
-- Name: lessons lessons_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- TOC entry 3320 (class 2606 OID 34857)
-- Name: materials materials_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3321 (class 2606 OID 34862)
-- Name: progresses progresses_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- TOC entry 3322 (class 2606 OID 34867)
-- Name: progresses progresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- TOC entry 3323 (class 2606 OID 34872)
-- Name: stream_students stream_students_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT "stream_students_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3324 (class 2606 OID 34877)
-- Name: stream_students stream_students_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT "stream_students_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3325 (class 2606 OID 34882)
-- Name: streams streams_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3326 (class 2606 OID 34887)
-- Name: streams streams_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


-- Completed on 2025-04-21 09:22:00 UTC

--
-- PostgreSQL database dump complete
--

